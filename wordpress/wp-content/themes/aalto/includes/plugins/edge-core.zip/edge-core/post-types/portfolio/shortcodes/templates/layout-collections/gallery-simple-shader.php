<?php echo edgtf_core_get_cpt_shortcode_module_template_part('portfolio', 'parts/image', $item_style, $params); ?>

<div class="edgtf-pli-shader-holder"></div>