<div class="edgtf-image-url-holder-inner">
	<div class="edgtf-image-url" <?php aalto_edge_inline_style($this_object->getItemBackgroundImage())?>></div>
</div>