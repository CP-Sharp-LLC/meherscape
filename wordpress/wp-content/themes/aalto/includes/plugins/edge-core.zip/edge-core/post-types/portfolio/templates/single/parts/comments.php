<?php if(aalto_edge_show_comments()) : ?>
    <?php comments_template('', true); ?>
<?php endif; ?>