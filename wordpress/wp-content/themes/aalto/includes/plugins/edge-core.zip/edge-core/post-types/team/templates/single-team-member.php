<?php

get_header();

aalto_edge_get_title();

do_action('aalto_edge_before_main_content');

edgtf_core_get_single_team();

get_footer();