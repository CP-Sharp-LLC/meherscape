<div class="edgtf-team-single-content">
	<?php the_content(); ?>
</div>