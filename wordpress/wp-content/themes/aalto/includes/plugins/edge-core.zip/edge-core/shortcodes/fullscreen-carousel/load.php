<?php

include_once EDGE_CORE_SHORTCODES_PATH . '/fullscreen-carousel/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH . '/fullscreen-carousel/fullscreen-carousel.php';