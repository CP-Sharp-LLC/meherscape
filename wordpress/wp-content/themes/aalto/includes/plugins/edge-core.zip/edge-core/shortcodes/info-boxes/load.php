<?php

include_once EDGE_CORE_SHORTCODES_PATH . '/info-boxes/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH . '/info-boxes/info-boxes.php';
include_once EDGE_CORE_SHORTCODES_PATH . '/info-boxes/info-boxes-item.php';