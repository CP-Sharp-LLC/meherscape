<div class="edgtf-info-boxes-outer clearfix <?php echo esc_attr($holder_classes); ?>">
	<?php echo do_shortcode($content); ?>
</div>