<?php

include_once EDGE_CORE_SHORTCODES_PATH . '/link-section/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH . '/link-section/link-section.php';