<?php

include_once EDGE_CORE_SHORTCODES_PATH . '/progress-bar/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH . '/progress-bar/progress-bar.php';