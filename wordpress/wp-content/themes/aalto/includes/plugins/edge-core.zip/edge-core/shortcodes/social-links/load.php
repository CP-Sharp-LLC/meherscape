<?php

include_once EDGE_CORE_SHORTCODES_PATH . '/social-links/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH . '/social-links/social-links.php';